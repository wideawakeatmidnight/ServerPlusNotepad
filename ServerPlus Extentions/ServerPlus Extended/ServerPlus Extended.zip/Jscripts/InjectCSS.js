//OCEAN BLUE CSS

//OceanBlue Body
//document.querySelector('body').style.background = '#082630';
//document.querySelector('body').style.color = '#ffffff';

//https://developer.chrome.com/extensions/tabs#method-insertCSS
//chrome.tabs.insertCSS(null, file{"/Templates/OceanBlue.css"});
