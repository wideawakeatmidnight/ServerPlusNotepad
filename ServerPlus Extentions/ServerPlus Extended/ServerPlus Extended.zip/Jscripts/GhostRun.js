//Instert Buttons on search page

  $(".page-header h2").append("&nbsp<a class='button_accept' id='ghostrun'>Ghost</a>");
  $(".page-header h2").append("&nbsp<a class='button_accept' id='voicemail'>Voicemail</a>");
  $(".button_accept").css("color","white");

  $(function ghostrun(){


  });
